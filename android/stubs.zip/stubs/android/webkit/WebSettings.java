// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.webkit;
public abstract class WebSettings { public void setJavaScriptEnabled(boolean b) { } public void setDomStorageEnabled(boolean b) { } public void setMediaPlaybackRequiresUserGesture(boolean b) { }
  public void setAllowFileAccess(boolean b) { } public void setAllowContentAccess(boolean b) { } public void setTextZoom(int z) { } public void setSupportZoom(boolean b) { } }
