// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.webkit;
public class WebView extends android.view.View { public WebView(android.content.Context c) { } public WebSettings getSettings() { return null; } public void addJavascriptInterface(Object o, String n) { }
  public void setWebViewClient(WebViewClient c) { } public void loadUrl(String u) { } public void evaluateJavascript(String s, ValueCallback<String> cb) { } public void onPause() { } public void onResume() { } public void destroy() { } }
