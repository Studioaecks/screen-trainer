// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.webkit;
public interface ValueCallback<T> { void onReceiveValue(T v); }
