// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.webkit;
public class WebResourceResponse { public WebResourceResponse(String m, String e, int c, String r, java.util.Map<String, String> h, java.io.InputStream d) { } }
