// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.webkit;
public class WebViewClient { public WebResourceResponse shouldInterceptRequest(WebView v, WebResourceRequest r) { return null; } public boolean shouldOverrideUrlLoading(WebView v, WebResourceRequest r) { return false; } }
