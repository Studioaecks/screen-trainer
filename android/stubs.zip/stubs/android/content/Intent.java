// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.content;
public class Intent { public static final int FLAG_ACTIVITY_SINGLE_TOP = 0x20000000; public Intent(Context c, Class<?> k) { }
  public Intent addFlags(int f) { return this; } public Intent setAction(String a) { return this; } public String getAction() { return null; } }
