// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.content;
public abstract class Context { public static final String NOTIFICATION_SERVICE = "notification", POWER_SERVICE = "power";
  public android.content.res.AssetManager getAssets() { return null; } public java.io.File getFilesDir() { return null; }
  public Object getSystemService(String n) { return null; } public android.content.ComponentName startService(Intent i) { return null; }
  public android.content.ComponentName startForegroundService(Intent i) { return null; } public boolean stopService(Intent i) { return false; }
  public android.content.pm.ApplicationInfo getApplicationInfo() { return null; } }
