// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.content.res;
public class AssetManager { public java.io.InputStream open(String n) throws java.io.IOException { return null; } }
