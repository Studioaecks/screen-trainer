// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.service.dreams;
public class DreamService extends android.app.Service { public void onAttachedToWindow() { } public void onDetachedFromWindow() { } public void onDreamingStopped() { }
  public void setInteractive(boolean b) { } public void setFullscreen(boolean b) { } public void setScreenBright(boolean b) { } public void setContentView(android.view.View v) { } public android.os.IBinder onBind(android.content.Intent i) { return null; } }
