// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.view;
public interface WindowManager { class LayoutParams { public static final int FLAG_KEEP_SCREEN_ON = 128; } }
