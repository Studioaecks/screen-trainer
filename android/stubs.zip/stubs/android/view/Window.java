// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.view;
public class Window { public static final int FEATURE_NO_TITLE = 1; public void addFlags(int f) { } public View getDecorView() { return null; } }
