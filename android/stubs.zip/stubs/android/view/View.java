// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.view;
public class View { public static final int OVER_SCROLL_NEVER = 2, SYSTEM_UI_FLAG_LAYOUT_STABLE = 256, SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION = 512, SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN = 1024, SYSTEM_UI_FLAG_HIDE_NAVIGATION = 2, SYSTEM_UI_FLAG_FULLSCREEN = 4, SYSTEM_UI_FLAG_IMMERSIVE_STICKY = 4096;
  public void setSystemUiVisibility(int v) { } public void setBackgroundColor(int c) { } public void setOverScrollMode(int m) { } public void setVerticalScrollBarEnabled(boolean b) { } public void setHorizontalScrollBarEnabled(boolean b) { } }
