// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.app;
public class NotificationChannel { public NotificationChannel(String id, CharSequence name, int imp) { } public void setShowBadge(boolean b) { } }
