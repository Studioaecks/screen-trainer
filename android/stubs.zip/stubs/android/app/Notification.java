// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.app;
public class Notification { public static class Builder { public Builder(android.content.Context c) { } public Builder(android.content.Context c, String ch) { }
  public Builder setSmallIcon(int i) { return this; } public Builder setContentTitle(CharSequence t) { return this; } public Builder setContentText(CharSequence t) { return this; }
  public Builder setOngoing(boolean o) { return this; } public Builder setContentIntent(PendingIntent p) { return this; } public Builder addAction(int icon, CharSequence t, PendingIntent p) { return this; }
  public Notification build() { return null; } } }
