// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.app;
public abstract class Service extends android.content.Context { public static final int START_NOT_STICKY = 2; public void onCreate() { } public void onDestroy() { }
  public int onStartCommand(android.content.Intent i, int f, int id) { return 0; } public void onTaskRemoved(android.content.Intent i) { } public abstract android.os.IBinder onBind(android.content.Intent i);
  public final void startForeground(int id, Notification n) { } public final void startForeground(int id, Notification n, int type) { } public final void stopSelf() { } }
