// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.app;
public class PendingIntent { public static final int FLAG_UPDATE_CURRENT = 0x08000000;
  public static PendingIntent getActivity(android.content.Context c, int r, android.content.Intent i, int f) { return null; } public static PendingIntent getService(android.content.Context c, int r, android.content.Intent i, int f) { return null; } }
