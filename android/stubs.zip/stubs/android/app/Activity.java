// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.app;
public class Activity extends android.content.Context { protected void onCreate(android.os.Bundle b) { } protected void onPause() { } protected void onResume() { } protected void onDestroy() { }
  public void onBackPressed() { } public void onWindowFocusChanged(boolean f) { } public boolean requestWindowFeature(int f) { return true; } public android.view.Window getWindow() { return null; }
  public void setContentView(android.view.View v) { } public boolean moveTaskToBack(boolean b) { return true; } }
