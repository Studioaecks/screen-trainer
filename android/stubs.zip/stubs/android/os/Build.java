// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.os;
public class Build { public static class VERSION { public static int SDK_INT = 34; } }
