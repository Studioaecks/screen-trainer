// A stand-in for the Android class of this name, only so tools/androidcheck.js can compile the shell without the Android SDK. Not packed into the app.
package android.os;
public class PowerManager { public static final int PARTIAL_WAKE_LOCK = 1; public WakeLock newWakeLock(int f, String t) { return null; }
  public class WakeLock { public void acquire() { } public void release() { } public boolean isHeld() { return false; } public void setReferenceCounted(boolean b) { } } }
